set_property SRC_FILE_INFO {cfile:/home/ullas/multiplier/multiplier.srcs/constrs_1/new/const.xdc rfile:../../../multiplier.srcs/constrs_1/new/const.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:87 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN Y9 [get_ports {clk}];  # "GCLK"
