`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 16.05.2024 22:57:14
// Design Name: 
// Module Name: vio_wrapper
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module vio_wrapper(
    input clk
    );
    
//    input wire CLK, RST, MODE, valid_in,
//    input [P3:0] in1,
//    input [P3:0] in2,
//    input [P2:0] op,
//    output [P2:0] res,
//    output valid_res

    // vio-out
    wire CLK, RST, MODE, valid_in;
    wire [1:0] in1, in2;
    wire [3:0] op; 
    // vio_in
    wire [3:0] res;
    wire valid_res;
    
    clk_wiz_0 instance_name
   (
    // Clock out ports
    .clk_out1(CLK),     // output clk_out1
   // Clock in ports
    .clk_in1(clk)); 
    
    
    vio_0 my_vio (
  .clk(CLK),                // input wire clk
  .probe_in0(res),    // input wire [3 : 0] probe_in0
  .probe_in1(valid_res),    // input wire [0 : 0] probe_in1
  .probe_out0(RST),  // output wire [0 : 0] probe_out1
  .probe_out1(MODE),  // output wire [0 : 0] probe_out2
  .probe_out2(valid_in),  // output wire [0 : 0] probe_out3
  .probe_out3(in1),  // output wire [1 : 0] probe_out4
  .probe_out4(in2),  // output wire [1 : 0] probe_out5
  .probe_out5(op)  // output wire [3 : 0] probe_out6
);

multiplier_two_bit
#(
    .P(7), // number of pbits - 1 = inputs+outputs-1
    .P2(3),
    .P3(1)
) my_mult_two_bit
(
    .CLK(CLK), .RST(RST), .MODE(MODE), 
    .valid_in(valid_in), .in1(in1), .in2(in2), 
    .op(op), .res(res), .valid_res(valid_res)
);

endmodule
