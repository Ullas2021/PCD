-makelib xcelium_lib/xil_defaultlib \
  "../../../../multiplier.srcs/sources_1/ip/vio_0/sim/vio_0.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  glbl.v
-endlib

